declare module "@salesforce/apex/ExpenseTrackerController.getCurrentMonthBudget" {
  export default function getCurrentMonthBudget(param: {selectedMonth: any}): Promise<any>;
}
declare module "@salesforce/apex/ExpenseTrackerController.getExpenses" {
  export default function getExpenses(param: {budgetId: any}): Promise<any>;
}
