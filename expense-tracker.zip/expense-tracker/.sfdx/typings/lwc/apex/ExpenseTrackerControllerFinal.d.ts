declare module "@salesforce/apex/ExpenseTrackerControllerFinal.getCurrentMonthBudget" {
  export default function getCurrentMonthBudget(param: {selectedMonth: any}): Promise<any>;
}
declare module "@salesforce/apex/ExpenseTrackerControllerFinal.getExpenses" {
  export default function getExpenses(param: {budgetId: any}): Promise<any>;
}
