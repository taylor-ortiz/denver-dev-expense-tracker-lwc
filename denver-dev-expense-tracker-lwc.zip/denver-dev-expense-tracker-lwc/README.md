# Denver Salesforce Developer Group - Salesforce Expense Tracker LWC:

Inflation and its effects have you in a tizzy! You recently got a higher than normal water bill and you screamed at the mail man. You think to yourself that you wish you had a way to track your expenses so that you can create more visibility into what you are spending. Being proficient in Salesforce as a developer, you decide to build an expense tracker Lightning Web Component that allows you to enter and track your expenses. 

## Steps
- Clone the repository from github into VS Code using the following command
- 



