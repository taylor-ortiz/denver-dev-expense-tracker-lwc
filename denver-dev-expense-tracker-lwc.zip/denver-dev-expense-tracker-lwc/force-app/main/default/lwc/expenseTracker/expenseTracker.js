import { LightningElement } from 'lwc';

export default class ExpenseTracker extends LightningElement {}